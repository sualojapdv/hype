<template>
  <div class="home-page">
    <h1>Bem-vindo à HomePage</h1>
    <p>Essa é a página principal.</p>
  </div>
</template>

<script>
export default {
  name: "HomePage",
};
</script>

<style scoped>
.home-page {
  text-align: center;
}
</style>